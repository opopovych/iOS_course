import UIKit

var text = "Hello. This is a homework task."
text.count
text.uppercased()
text.first
if let range = text.range(of:"a") {
     text.replacingCharacters(in: range, with:"my")
 }
text.dropLast(6)
var text1 = "I study Swift language"
var text2 = " So far everything goes very smoothly."
var text3 = " I like it."

text1+text2+text3
text1+=text2+text3
text1.append(text2)

var fibArray:Array<Int> = [0,1,1,2,3,5,8,13,21,34]
let revArray :[Int]=fibArray.reversed()
fibArray
fibArray.insert(11, at: 3)
fibArray.insert(12, at: 5)
fibArray.remove(at: 1)
fibArray.remove(at: 7)
var sorted:[Int]=fibArray.sorted().reversed()
let max = fibArray.max()
let min = fibArray.min()

let mySet1: Set = ["a","b","c","d","e"]
var mySet2: Set = ["c","d"]
mySet2.insert("z")
mySet2
mySet1.intersection(mySet2)
mySet1.isDisjoint(with: mySet2)
var newSet: Set = mySet1.union(mySet2)
newSet

var nDic : [Int: String] = [
    1:"one",
    2:"two",
    3:"three",
    4:"four",
    5:"five",
    6:"six",
    7:"seven",
    8:"eight",
    9:"nine",
    10:"ten"
]
nDic[3]
nDic[4]
nDic.keys
nDic[11] = "eleven"
nDic
let number=Array(nDic.values)

let distance : Range = 10..<20
distance.count
let hasTwenty = distance~=20


